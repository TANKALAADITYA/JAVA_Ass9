package corejava;

interface Quantiphi {
	void Trainer();
	void ProgrammingLanguage();
	void assignment();
    void time();
}


abstract class Newlearner implements Quantiphi {

	 public void Trainer()
	{
		System.out.println(
			"welcome!! to quantiphi$$");
	}
     public void ProgrammingLanguage()
	{
		System.out.println(
			"we are going to learn core jave@@");
	}
    public void time(){
        System.out.println("before EOD of monday");
    }
}

class Student extends Newlearner {
	 public void assignment()
	{
		System.out.println(
			"submit before deadline");
	}
}


public class question1 {
	public static void main(String[] args)
	{

		Student Student1 = new Student();

		Student1.Trainer();
		Student1.ProgrammingLanguage();
		Student1.assignment();
        Student1.time();
	}
}

