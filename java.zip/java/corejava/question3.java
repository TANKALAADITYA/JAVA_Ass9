package corejava;

class fetchData extends Thread{
    public void show(){
        for(int i=0;i<=3;i++){
            System.out.println("this is fetch data thread");
            try{
                Thread.sleep(5000);
            }
            catch(Exception e)
            {

            }
        }
    }
    
}
class processData implements Runnable
{
    public void run(){
        for(int i=1;i<=3;i++){
            System.out.println("this is processData");
            try{
                Thread.sleep(10000);
            }
            catch(Exception e)
            {

            }
        }
    }
}
public class question3 {
        public static void main(String args[])
    {
        fetchData obj=new fetchData();
        processData obj1=new processData();
        obj.show();
        obj1.run();
    }
    
}